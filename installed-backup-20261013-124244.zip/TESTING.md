# Electrical accuracy update

Latest release: **0.8.0**, with experimental thermal analysis. Earlier sections
describe the release history; current thermal features and limitations appear
at the end of this document.

The shared KiPIDA folder contains the updated source. Original core files are in
`review_backup/`. The PCM ZIP beside the folder contains only runtime files and package metadata;
it excludes the test environment, caches, backups, and development scripts.

## Test in KiCad

1. Use KiCad **9.0.1 or newer** and enable its IPC API.
2. In KiCad's Plugin and Content Manager choose **Install from File** and select
   `KiPIDA-PCM.zip` beside this folder. It contains root `metadata.json` and a
   `plugins/` payload, validated against the official KiCad schemas.
   `KiPIDA-fixed.zip` is now an identical compatibility copy of this PCM installer.
3. Restart KiCad. If you previously installed KiPIDA manually, remove that old
   manual copy to avoid two plugins with the same identifier. Keep your project
   configuration files. This build uses the original KiPIDA identifier.
4. Open a board with a physical stackup, refill zones, and launch KiPIDA. The
   plugin runtime requires NumPy, SciPy, Shapely, Matplotlib, wxPython, and
   kicad-python, listed in `requirements.txt`. The shared `.venv/` is only for tests.
5. Keep **Check mesh convergence** enabled. Start with 0.1 mm spacing. If a pad
   or annular ring has no mesh nodes, or refinement changes voltage drop/total
   loss by more than 5%, halve the spacing and run again.
6. Verify voltage drop, total copper loss (W), current balance, and mesh status.
   Unmapped or disconnected loads now stop the simulation with an explanation.
7. Try a regulator chain: a 5 V / 1 A load supplied by a 10 V input at 80%
   efficiency draws 0.625 A at its input when the local input voltage is 10 V.
   Copper and series drops increase switching-regulator input current.

The previous ZIP was a manual-extraction archive, which caused the PCM error
about missing metadata.json. Neither the plugin icon nor the packaged PNGs
contain iCCP or cHRM chunks; those warnings have not been traced to KiPIDA.

## Applied changes

- Removed duplicate regulator input-current stamping.
- Removed 0.05 mm copper widening on each side of traces and vias.
- Use KiCad's pad polygons and actual copper layers for terminals and extraction.
- Preserve polygon holes and prevent neighbor links across copper gaps.
- Weight lateral conductance by the copper width at each cell face.
- Use finished drill diameter, plating thickness, and physical stackup distances
  for via/PTH barrels. Slotted PTH barrels use the slot perimeter.
- Do not attach vertical connections to nodes outside the contact geometry.
- Map IPC layer IDs correctly in the offline fallback; connected-board stackup
  failures stop the run instead of substituting a guessed two-layer stackup.
- Eliminate voltage boundaries while preserving matrix symmetry; reject invalid
  boundaries, non-finite solutions, excessive residuals, and current imbalance.
- Exclude unloaded, unpowered copper islands from voltage results and plots.
- Clear results on failure so earlier or partial results are not shown as valid.
- Compare coarse and half-spacing meshes, using the refined results after a pass.
- Report total copper loss and correct the README's unimplemented feature claims.

## Verification

Run from this folder in PowerShell:

```powershell
$env:MPLCONFIGDIR = Join-Path (Get-Location) '.mpl-cache'
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

39 checks passed, with one GUI import check skipped because wxPython is unavailable
in the isolated test environment. Checks cover analytical rectangular-trace
resistance at three mesh spacings, copper loss, holes, gaps, via conductance and
vertical connectivity, real IPC pad polygon types, disconnected loads, sparse node
IDs, terminal layer restrictions, and production rail orchestration. The production
orchestration check also exercises successful and rejected mesh refinement.

The live KiCad connection and dialog still need your test.

## Model limits

This update implements electrical corrections and total Joule power loss. It does
not add local current-density plots or temperature prediction. Copper resistivity
is fixed. Explicitly stitched nets are solved together; return-path resistance is omitted.

Via/PTH plating defaults to **25 micrometres**, logged during meshing. The model
accepts a `via_plating_mm` stackup field, but a user-editable plating control is
not yet present. Barrel contacts remain lumped at a representative node within
each annular pad; current crowding near these contacts needs further refinement.

The 5% refinement check covers rail voltage drop, integrated copper loss, and
series-component current/drop/loss, not local
peak current density. Curved API polygon boundaries are approximated by segments
of at most two degrees. The rectangular grid can require small spacing for narrow
or diagonal features. Grid size is limited by the estimated RAM/VRAM budgets
instead of a fixed two-million-point cap (see 0.7.0 below).

## Series components (0.6.0)

1. Select the supply rail and set its source and supply voltage at the actual
   input connector. Put the load at its real downstream terminal.
2. Click **+ Series Component**, choose F1, and select its two pads. The pad nets
   come from the board; missing nets are added to the rail list automatically.
3. Enter the component resistance in **milliohms**, using a datasheet or measured
   value. For example, 20 mOhm at 2 A produces 40 mV drop and 0.08 W loss.
   Zero means an ideal connection. Clear **Connected** to model an open fuse.
4. Remove any artificial source or load previously placed at F1 to analyze
   the two sides separately. The fuse is now the connection between those sides.
   The intermediate rail's nominal voltage does not clamp its solved voltage.
5. Run with mesh convergence enabled. Read signed A-to-B component current,
   A-minus-B voltage, component loss, and separate total copper/component losses.
6. Double-click a series row on either rail to edit it; **- Remove** deletes
   the link. Save Config persists it. Existing version 1.0 files still load;
   newly saved files use version 1.1 and require this updated plugin.

Passive links are bidirectional and can form branched networks. Contacts are
lumped equipotential electrodes within each selected pad. Ideal-link loop currents
may be indeterminate and are labelled accordingly. Regulator dependencies must be
acyclic, with distinct input/output networks and uniquely attributable output
terminals. Switching inputs use an iterated constant-power load; failures to
converge stop the solve. Linear-regulator quiescent current is omitted.

This is a fixed-resistance electrical model: component watts estimate Joule heat
production, not temperature, fuse trip time, or a coupled thermal solution.

## Startup troubleshooting

The installed launcher appends startup details to `%TEMP%/kipida_entry.log`
and explicitly raises the analysis dialog on Windows. Connection failures
produce a foreground error with the exception and log path.

If clicking the toolbar icon produces no new log entry, KiCad has not invoked
the launcher. Restart the PCB Editor and KiCad manager to reload the plugin,
and check that the tooltip identifies **Ki-PIDA Simulation**. Keep the board
open when launching. The shared folder also contains `Start KiPIDA.cmd`, a
direct launcher for this user's KiCad 9 installed runtime; it bypasses toolbar
dispatch and connects to the running board without editing it.

## Windows toolbar bridge (0.6.1)

KiCad 9's IPC toolbar dispatch did not start the launcher on the tested system,
although directly starting the same installed runtime opened the dialog. This
build registers a minimal pcbnew ActionPlugin toolbar bridge on Windows. It
launches the isolated runtime without importing analysis dependencies inside
KiCad. The electrical analysis and board access still use IPC. The manifest's
IPC action remains available as **Ki-PIDA Simulation (IPC)** with its toolbar
button hidden, avoiding duplicate icons after reload.

Reload Python action plugins or reopen the PCB Editor after this update. The
new toolbar tooltip is **Open KiPIDA (KiCad 9 toolbar bridge)**. Bridge launch
events are appended to `%TEMP%/kipida_toolbar.log`; analysis startup is logged
in `%TEMP%/kipida_entry.log`. Missing runtime files produce a KiCad error dialog.
42 executable checks pass, plus one GUI import check is skipped in the isolated
test environment. The real KiCad-managed Python runtime also exercises the
bridge launch with the open board. Actual toolbar dispatch needs user testing.

## Series dialog fix (0.6.2)

KiCad IPC footprint references contain BoardText objects; the series dialog
now extracts their string values before sorting component choices. Constructor
failures are logged and displayed rather than appearing as an inactive button.
Regression coverage includes actual FootprintInstance, Field, BoardText and Pad
protobuf wrappers. 44 executable checks pass with one GUI import check skipped.
The dialog was also constructed and displayed against the user's open board.

## Series chain list and defaults (0.6.3)

The component list shows every series link in the selected net's connected
chain, including open links and links farther downstream. Each row identifies
both nets and pads; editing and deletion use the link's owning rail. A newly
added link is selected and scrolled into view. If it belongs to a separate
chain, its first rail is selected automatically so the new link is visible.
New series components default to 0 mOhm (ideal connection); editing preserves
the configured resistance. Series, source/load and regulator component choices
use natural reference sorting (R2, R3, R10, R29); series pad numbers also sort
numerically. 48 executable checks pass with one GUI import check skipped.
Real wx controls verified downstream rows, deletion, default and ordering.

## Filled-zone boundary reconstruction (0.6.4)

Some IPC filled polygons express holes or islands with doubled zero-width
boundary seams. Shapely considers these rings self-intersecting. The parser
now reconstructs valid area polygons and discards leftover line geometry.
It accepts the reconstruction only when the copper area is preserved within
a tolerance of max(1e-12 mm2, 1e-10 times the original area). Repairs that
change copper area still fail, with the net/layer and validity reason included.
This does not enlarge copper or treat a boundary seam as a conductive bridge.

All 66 filled-zone polygons on the open board passed the corrected parser.
52 executable tests passed, with one GUI import skipped. New regressions cover
bridged holes, disconnected islands, genuine crossing rejection, and explicit
holes. The complete simulation of the user's unsaved configuration still needs
a rerun. Save Config before closing and reopening KiPIDA to load this update.

## Large meshes and optional CUDA (0.7.0)

Save Config, then close and reopen KiPIDA to load the update. The new Solver
control offers Auto, CPU and GPU (CUDA). Auto tries CUDA for at least 50,000
free voltage unknowns and falls back to CPU if CUDA is unavailable or fails
its checks. Explicit GPU reports failure instead of falling back. Results and
the log show the backend, iteration count and solve time.

The default RAM budget is the smaller of 8 GB and 25% of available RAM. Preflight
uses a conservative estimate covering mesh arrays, network assembly and solver
workspaces, capped at 70% of currently available RAM. It is an estimate, not an
operating-system allocation quota. Refinement has four times as many candidate
grid points and also retains the coarse mesh; increase the budget if this step
exceeds it. Start with 8 GB; 16 GB can accommodate larger refinements on this
64 GB machine when sufficient RAM remains available. Keep convergence enabled.
GPU workspaces are checked against free VRAM before allocation.

Coordinates, voltage results, conductance entries and network node mappings now
use compact arrays. Rasterization and copper-face evaluation run in bounded
batches. Pad/via lookups use local grid windows. Geometry extraction, meshing,
assembly and validation still run on CPU; only the sparse solve uses CUDA.
Large plots sample approximately 200,000 points for display; all electrical
nodes participate in the solve and loss/current checks. Plot titles identify
sampling. This release still does not implement current-density or temperature
maps.

CUDA is optional. Install `requirements-gpu.txt` using the plugin's own Python
runtime, not KiCad's embedded pcbnew Python or the development `.venv`:

```powershell
& '<plugin-runtime-python.exe>' -m pip install --no-cache-dir -r requirements-gpu.txt
```

This user's KiCad 9 runtime already has CuPy 14.2.0 and CUDA 12 component wheels
installed and verified on the RTX 3080 Ti (12 GB VRAM, driver 566.36). The PCM
archive includes the optional requirements file, but does not force a CUDA
installation for other users. CPU analysis uses `requirements.txt`.

Validation on this machine:

- The CPU test suite executes 65 checks, with three environment-dependent checks
  skipped (wx import and two optional real-CUDA checks). Real wx controls and
  compact voltage rendering were verified separately against the open board.
- Four backend tests pass in the actual plugin runtime, including real CUDA
  voltage/loss/current balance and stitched rails with ideal and resistive fuses.
- Analytical 262,144-node grid: CPU CG 5.65 s, CUDA CG 1.96 s; maximum CPU/GPU
  voltage difference 7.13e-14 V (`benchmark-gpu-512.json`).
- Analytical 2,359,296-node grid: CUDA CG 9.58 s; maximum analytical error
  8.58e-12 V and residual 1.03e-13 A (`benchmark-gpu-1536.json`). No CPU timing
  was measured at this size. These timings cover the reduced sparse solve.
- The open PowerCreep board's GND geometry at 0.1 mm successfully meshes
  5,889,624 candidate points into 3,439,501 copper nodes across four layers in
  82.75 s (`benchmark-live-gnd.json`). This is a meshing check, not an electrical
  simulation of the user's unsaved source/load configuration.

`benchmark_gpu.py` reproduces the analytical grid benchmark. GPU CG still has
a convergence limit; very ill-conditioned networks may require different mesh
spacing or CPU analysis. Finite-value, residual, source/load balance, topology
and mesh-refinement checks remain in force for either backend.

## Combined layer voltage plots (0.7.1)

Results now opens with an **All Rails** notebook. Each copper-layer tab overlays
every solved rail present on that layer in its original PCB X/Y coordinates,
with net labels and a single absolute voltage color scale shared across layers.
The scale spans the full solved system voltage range; it is independent of the
per-rail Max Drop % setting. Individual rail tabs retain their detailed drop
scales. Copper gaps and separate nets are not interpolated or electrically joined
by this display. Unpowered nodes are excluded. Each combined layer distributes
an approximately 200,000-point display budget across its rails; full electrical
results remain unchanged.

67 CPU-suite checks pass with three environment-dependent checks skipped.
Regressions cover board positions, layer filtering, omitted unpowered nodes,
common color normalization and an empty layer. The actual KiCad wx runtime also
checks the combined result notebook and plots. Save Config and reopen KiPIDA,
then rerun the simulation to populate **Results > All Rails > F.Cu/B.Cu/etc.**

## Experimental thermal analysis (0.8.0)

Save Config and reopen KiPIDA. Enable **Thermal estimate (copper + series heat)**
before Run Simulation. Defaults are ambient 25 °C, h=10 W/(m² K) on EACH board
face, 1 mm thermal grid, substrate k=0.3 W/(m K), and copper k=400 W/(m K).
These are editable modeling assumptions (copper k currently fixed), not measured
properties or an automatically determined convection coefficient. Thermal controls
currently reset when the dialog is reopened; Save Config persists the power tree.
Use suitable substrate and cooling values for your board and environment.

The new **Temperature (board average)** tab uses the actual closed board-level
Edge.Cuts outline, including cutouts. Segments, arcs, circles and rectangles are
supported; unsupported shapes or open contours fail explicitly. It uses a
cell-centered finite-volume steady-state thin-board model:

`-div((k_sub*t_sub + sum(k_cu*t_cu))*grad(T)) + 2*h*(T-Tambient) = heat/area`

Copper contributions are restricted to supplied copper geometries at each cell
face. Dielectric thickness comes from the physical stackup. Cell boundary areas
and face widths are clipped to Edge.Cuts; the board edge is insulated. Convection
acts on both broad faces. See [thin-structure heat transfer theory](https://doc.comsol.com/6.4/doc/com.comsol.help.heat/heat_ug_theory.07.028.html)
for the thickness-integrated formulation.

Every solved copper edge supplies `G*(Va-Vb)^2` watts, divided between its
endpoints, including electrical via/PTH loss. The mapped power must match each
rail's electrical copper-loss total. Series component loss is split equally
between its two pad contacts. All this series loss is assumed to enter the PCB.
The solver checks finite temperatures, nonnegative temperature rise, residual
and total heat rejection. With **Check mesh convergence** enabled, a second
thermal solve at half spacing must change peak temperature rise by no more than
5%; the refined map is then displayed. Thermal failure retains valid electrical
results and explains why the temperature estimate is unavailable. RAM checks
include the retained electrical mesh; Auto/CPU/GPU also applies to thermal solves.

Limits of this FIRST thermal model:

- Temperature is uniform through board thickness; the plot is board-average,
  not separate layer temperatures or component junction temperatures.
- Only electrically selected rail copper contributes to spreading. Unselected
  copper planes, packages, heatsinks, mounting screws and other heat paths are
  omitted. All board dielectric still participates.
- Loads and regulators do not yet contribute their own device dissipation.
  Applied load power is not treated as copper heat. Radiation and airflow
  calculation are omitted; h is a prescribed per-face coefficient.
- Electrical copper resistivity is fixed; temperature feedback and iterative
  electrothermal coupling are not implemented. This is a first-pass estimate
  rather than a sign-off temperature prediction.
- Features below thermal grid spacing may be unresolved; refine the grid,
  particularly around narrow cutouts or localized heat sources.

Verification: eight thermal regressions cover analytical uniform cooling,
two-cell heat spreading, copper conductance, cutouts/islands, partial boundary
cell area, electrical-to-thermal power conservation including vias, refinement,
invalid inputs and outline parsing. The full suite has 76 checks, with four
environment-dependent skips in the CPU test environment. Five backend checks
pass in the actual runtime, including an analytical thermal CUDA solve.
The real KiCad UI pipeline was tested on PowerCreep's 14,480.24 mm² outline:
14,619 thermal cells with 2.08 W of SYNTHETIC copper/series test heat and
6.22e-15 W heat-balance error. The user's actual configured power tree still
needs a thermal run. `check_thermal_ui.py` reproduces that read-only smoke check.
