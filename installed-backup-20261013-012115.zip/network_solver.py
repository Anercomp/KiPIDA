"""Assemble copper nets and explicit passive component contacts into DC networks."""
import math
import numpy as np
from compact_storage import Voltages
from collections import defaultdict
from mesh import Mesh
from electrical_solver import Solver


class Union:
    def __init__(self, items):
        self.parent = {item: item for item in items}

    def find(self, item):
        root = item
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[item] != item:
            item, self.parent[item] = self.parent[item], root
        return root

    def join(self, a, b):
        self.parent[self.find(b)] = self.find(a)


class EdgeArrays:
    def __init__(self, mesh):
        if mesh.G_coo_data:
            data = np.asarray(mesh.G_coo_data)
            row, col = np.asarray(mesh.G_coo_row), np.asarray(mesh.G_coo_col)
            mask = (row < col) & (data < 0)
            self.u, self.v, self.g = row[mask], col[mask], -data[mask]
        elif mesh.edges:
            edges = np.asarray(mesh.edges)
            self.u, self.v, self.g = edges[:, 0].astype(int), edges[:, 1].astype(int), edges[:, 2]
        else:
            self.u, self.v, self.g = np.empty(0, dtype=int), np.empty(0, dtype=int), np.empty(0)

    def __iter__(self):
        return iter(zip(self.u, self.v, self.g))


def copper_edges(mesh):
    return EdgeArrays(mesh)


class Layout:
    def __init__(self, meshes):
        self.offsets, self.sparse = {}, {}
        self.count = 0
        for net, mesh in meshes.items():
            self.offsets[net] = self.count
            if not isinstance(mesh.nodes, range) or mesh.nodes != range(len(mesh.nodes)):
                self.sparse[net] = {int(node): i for i, node in enumerate(mesh.nodes)}
            self.count += len(mesh.nodes)

    def indices(self, net, nodes):
        if net in self.sparse:
            nodes = [self.sparse[net][int(node)] for node in nodes]
        return self.offsets[net]+np.asarray(nodes, dtype=np.int32)


class NodeIDs:
    def __init__(self, layout, ids):
        self.layout, self.ids = layout, ids

    def __getitem__(self, key):
        net, node = key
        offset = self.layout.offsets[net]
        index = self.layout.sparse[net][int(node)] if net in self.layout.sparse else int(node)
        return int(self.ids[offset+index])


class ArrayUnion:
    def __init__(self, count):
        self.parent = np.arange(count, dtype=np.int32)

    def find(self, node):
        root = node
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[node] != node:
            node, self.parent[node] = self.parent[node], root
        return int(root)

    def join(self, a, b):
        self.parent[self.find(b)] = self.find(a)

    def roots(self):
        while True:
            parents = self.parent[self.parent]
            if np.array_equal(parents, self.parent):
                return parents
            self.parent = parents


def stamp_edges(mesh, u, v, g):
    valid = u != v
    u, v, g = u[valid], v[valid], g[valid]
    mesh.G_coo_row.extend(np.concatenate((u, v, u, v)))
    mesh.G_coo_col.extend(np.concatenate((u, v, v, u)))
    mesh.G_coo_data.extend(np.concatenate((g, g, -g, -g)))


def solve_group(meshes, links, sources, loads, resolve, log=None, backend='auto'):
    layout = Layout(meshes)
    union = ArrayUnion(layout.count)

    def terminal(net, ref, pads):
        nodes = resolve(meshes[net], ref, pads)
        if not nodes:
            raise ValueError(f"No mapped terminal: {ref} {pads} on {net}.")
        ids = layout.indices(net, nodes)
        for node in ids[1:]:
            union.join(ids[0], node)
        return int(ids[0])

    contacts, seen = [], set()
    for link in links:
        if not math.isfinite(link.resistance_ohm) or link.resistance_ohm < 0:
            raise ValueError(f"Invalid resistance for {link.ref_des}.")
        key = frozenset(((link.ref_des, link.pad_a), (link.ref_des, link.pad_b)))
        if key in seen or len(key) != 2 or link.net_a == link.net_b:
            raise ValueError(f"Duplicate or invalid series link: {link.ref_des}.")
        seen.add(key)
        contacts.append((link, terminal(link.net_a, link.ref_des, [link.pad_a]),
                         terminal(link.net_b, link.ref_des, [link.pad_b])))
    mapped_sources = [(terminal(net, ref, pads), amount) for net, ref, pads, amount in sources]
    mapped_loads = [(terminal(net, ref, pads), amount) for net, ref, pads, amount in loads]
    before = union.roots()
    for link, a, b in contacts:
        if link.closed and link.resistance_ohm == 0:
            union.join(a, b)
    unique, node_id = np.unique(union.roots(), return_inverse=True)
    node_id = node_id.astype(np.int32)
    combined = Mesh(); combined.nodes = range(len(unique))
    edges = {net: copper_edges(mesh) for net, mesh in meshes.items()}
    for net, items in edges.items():
        u, v = node_id[layout.indices(net, items.u)], node_id[layout.indices(net, items.v)]
        stamp_edges(combined, u, v, items.g)
    for link, a, b in contacts:
        if link.closed and link.resistance_ohm > 0:
            combined.add_edge_direct(int(node_id[a]), int(node_id[b]), 1/link.resistance_ohm)
    solver = Solver(log_callback=log, backend=backend)
    solution = solver.solve(combined,
        [dict(node_id=int(node_id[node]), voltage=v) for node, v in mapped_sources],
        [dict(node_id=int(node_id[node]), current=i) for node, i in mapped_loads])
    if isinstance(solution, Voltages):
        voltages = solution.array
    else:
        voltages = np.full(len(unique), np.nan)
        for node, voltage in solution.items():
            voltages[node] = voltage
    results = {}; external = np.zeros(layout.count)
    for net, mesh in meshes.items():
        count, offset = len(mesh.nodes), layout.offsets[net]
        local = voltages[node_id[offset:offset+count]]
        values = Voltages(local) if net not in layout.sparse else {n: float(local[i]) for i, n in enumerate(mesh.nodes) if np.isfinite(local[i])}
        items = edges[net]
        a, b = layout.indices(net, items.u), layout.indices(net, items.v)
        delta = voltages[node_id[a]]-voltages[node_id[b]]
        current = np.nan_to_num(items.g*delta, nan=0.0)
        loss = float(np.nansum(current*delta))
        np.add.at(external, before[a], current)
        np.add.at(external, before[b], -current)
        if len(values):
            lo, hi = float(np.nanmin(local)), float(np.nanmax(local))
            results[net] = dict(mesh=mesh, results=values, stats=(lo, hi, hi-lo),
                                diagnostics={**solver.diagnostics, 'copper_loss_w': loss})
    for node, current in mapped_loads:
        external[before[node]] += current
    source_contacts = defaultdict(set)
    for node, _ in mapped_sources:
        source_contacts[int(node_id[node])].add(int(before[node]))
    ambiguous = set()
    for nid, terminals in source_contacts.items():
        if len(terminals) == 1:
            external[next(iter(terminals))] -= solver.diagnostics['source_currents_a'][nid]
        else:
            ambiguous.update(terminals)
    component_results, ideal = [], []
    for link, a, b in contacts:
        va, vb = voltages[node_id[a]], voltages[node_id[b]]
        drop = float(va-vb) if np.isfinite(va) and np.isfinite(vb) else None
        current = 0.0 if not link.closed else (drop/link.resistance_ohm if drop is not None and link.resistance_ohm else None)
        record = dict(ref=link.ref_des, net_a=link.net_a, net_b=link.net_b, closed=link.closed,
                      current_a=current, drop_v=drop, loss_w=0.0 if current is None else current*current*link.resistance_ohm)
        component_results.append(record)
        if link.closed and link.resistance_ohm == 0 and drop is not None:
            ideal.append((int(before[a]), int(before[b]), record))
        elif current is not None:
            external[before[a]] += current
            external[before[b]] -= current
    remaining = list(ideal)
    while remaining:
        degree = defaultdict(int)
        for a, b, _ in remaining:
            degree[a] += 1; degree[b] += 1
        progress = False
        for a, b, record in list(remaining):
            if degree[a] == 1 and a not in ambiguous:
                current = -external[a]
            elif degree[b] == 1 and b not in ambiguous:
                current = external[b]
            else:
                continue
            record['current_a'] = float(current)
            external[a] += current; external[b] -= current
            remaining.remove((a, b, record)); progress = True
            break
        if not progress:
            break
    return results, component_results, solver.diagnostics, NodeIDs(layout, node_id)


def solve_system(rails, meshes, resolve, log=None, backend='auto'):
    rail_map = {rail.net_name: rail for rail in rails}
    links = [link for rail in rails for link in rail.series_components]
    regs = [reg for rail in rails for reg in rail.child_regulators]
    if len({reg.name for reg in regs}) != len(regs):
        raise ValueError("Regulator names must be unique.")
    groups = Union(meshes)
    # Open links are assembled too, so a disconnected downstream load fails validation.
    for link in links:
        groups.join(link.net_a, link.net_b)
    members = defaultdict(list)
    for net in meshes:
        members[groups.find(net)].append(net)
    results, components, solved, visiting = {}, [], {}, set()

    def solve(root):
        if root in solved:
            return
        if root in visiting:
            raise ValueError("Regulator dependency cycle through stitched rails.")
        visiting.add(root)
        nets = members[root]
        sources, loads = [], []
        for net in nets:
            rail = rail_map[net]
            sources.extend((net, s.component_ref.ref_des, s.pad_names, rail.nominal_voltage) for s in rail.sources)
            loads.extend((net, l.component_ref.ref_des, l.pad_names, l.total_current) for l in rail.loads)
        incoming, outgoing = [], []
        for reg in regs:
            upstream, downstream = groups.find(reg.input_rail_name), groups.find(reg.output_rail_name)
            if upstream == downstream:
                raise ValueError(f"Regulator {reg.name} input and output are in one stitched network.")
            if downstream == root:
                incoming.append(reg)
                sources.append((reg.output_rail_name, reg.output_ref_des, reg.output_pad_names, rail_map[reg.output_rail_name].nominal_voltage))
            if upstream == root:
                solve(downstream)
                outgoing.append(reg)
        source_voltage = max((s[3] for s in sources), default=0)
        input_currents = []
        for reg in outgoing:
            if reg.reg_type not in ('LINEAR', 'SWITCHING') or not 0 < reg.efficiency <= 1:
                raise ValueError(f"Invalid regulator model: {reg.name}.")
            current = solved[groups.find(reg.output_rail_name)][reg.name]
            if current < -1e-8:
                raise ValueError(f"Regulator {reg.name} is absorbing current; reverse operation is unsupported.")
            if source_voltage <= 0:
                raise ValueError("Regulator input network needs a positive supply voltage.")
            input_currents.append(max(0, current) if reg.reg_type == 'LINEAR' else
                                  max(0, current)*rail_map[reg.output_rail_name].nominal_voltage/reg.efficiency/source_voltage)
        local_links = [link for link in links if link.net_a in nets]
        for iteration in range(40):
            regulator_loads = [(r.input_rail_name, r.input_ref_des, r.input_pad_names, i) for r, i in zip(outgoing, input_currents)]
            data, parts, diagnostics, ids = solve_group({n: meshes[n] for n in nets}, local_links, sources, loads+regulator_loads, resolve, log, backend)
            updated = []
            for reg, old in zip(outgoing, input_currents):
                nodes = resolve(meshes[reg.input_rail_name], reg.input_ref_des, reg.input_pad_names)
                vin = data[reg.input_rail_name]['results'][nodes[0]]
                if vin <= 0:
                    raise ValueError(f"Regulator {reg.name} has nonpositive input voltage.")
                current = solved[groups.find(reg.output_rail_name)][reg.name]
                updated.append(max(0, current) if reg.reg_type == 'LINEAR' else
                               max(0, current)*rail_map[reg.output_rail_name].nominal_voltage/reg.efficiency/vin)
            if all(abs(a-b) <= 1e-10+1e-9*abs(b) for a, b in zip(input_currents, updated)):
                break
            input_currents = [(a+b)/2 for a, b in zip(input_currents, updated)]
        else:
            raise ValueError("Regulator constant-power input did not converge.")
        supplied = {}
        claimed = set()
        for reg in incoming:
            nodes = resolve(meshes[reg.output_rail_name], reg.output_ref_des, reg.output_pad_names)
            source_ids = {ids[reg.output_rail_name, n] for n in nodes}
            if claimed & source_ids:
                raise ValueError("Regulator outputs share a terminal; current allocation is ambiguous.")
            standard_ids = {ids[net, n] for net, ref, pads, _ in sources[:len(sources)-len(incoming)] for n in resolve(meshes[net], ref, pads)}
            if source_ids & standard_ids:
                raise ValueError("Remove the manual source at the regulator output terminal.")
            claimed.update(source_ids)
            supplied[reg.name] = sum(diagnostics['source_currents_a'][n] for n in source_ids)
        results.update(data)
        components.extend(parts)
        solved[root] = supplied
        visiting.remove(root)
    for root in members:
        solve(root)
    return results, components
