"""Validated float64 sparse backends; CUDA is optional and lazily imported."""
import time
import numpy as np
from scipy.sparse import linalg


def solve_reduced(matrix, rhs, backend='auto', log=None):
    if backend not in ('auto', 'cpu', 'gpu'):
        raise ValueError('Unknown solver backend.')
    started = time.perf_counter()
    notes = []
    diagonal = matrix.diagonal()
    if np.any(diagonal <= 0):
        raise ValueError('Reduced conductance has a nonpositive diagonal.')
    iterations = [0]
    last_log = [started]
    def count(_):
        iterations[0] += 1
        now = time.perf_counter()
        if log and now-last_log[0] > 2:
            log(f'Sparse solve: {iterations[0]} iterations, {now-started:.1f} s.')
            last_log[0] = now
    maximum = min(30000, max(2000, int(12*np.sqrt(len(rhs)))))
    if backend == 'gpu' or (backend == 'auto' and len(rhs) >= 50000):
        try:
            import cupy as cp
            from cupyx.scipy.sparse import csr_matrix
            from cupyx.scipy.sparse.linalg import cg, LinearOperator
            free, _ = cp.cuda.runtime.memGetInfo()
            required = 3*(matrix.data.nbytes+matrix.indices.nbytes+matrix.indptr.nbytes)+len(rhs)*128
            if required+256*1024**2 > free*.8:
                raise RuntimeError(f'CUDA estimated workspace {required/1024**3:.2f} GB exceeds free VRAM budget.')
            gpu_matrix = csr_matrix(matrix)
            gpu_rhs = cp.asarray(rhs, dtype=cp.float64)
            inverse = 1/cp.asarray(diagonal)
            preconditioner = LinearOperator(matrix.shape, matvec=lambda x: inverse*x, dtype=cp.float64)
            result, info = cg(gpu_matrix, gpu_rhs, M=preconditioner, rtol=1e-10, atol=1e-11,
                              maxiter=maximum, callback=count)
            if info != 0:
                raise RuntimeError(f'CUDA CG did not converge after {iterations[0]} iterations (status {info}).')
            result = cp.asnumpy(result)
            error = float(np.max(np.abs(matrix@result-rhs)))
            if not np.all(np.isfinite(result)) or error > 1e-9+1e-8*max(1, float(np.max(np.abs(rhs)))):
                raise RuntimeError(f'CUDA residual check failed: {error:.3g} A.')
            name = cp.cuda.runtime.getDeviceProperties(0)['name']
            if isinstance(name, bytes):
                name = name.decode()
            diagnostics = dict(backend='CUDA CG', gpu=name, iterations=iterations[0],
                               solve_seconds=time.perf_counter()-started, backend_notes=notes)
            if log:
                log(f"CUDA CG on {name}: {iterations[0]} iterations, {diagnostics['solve_seconds']:.2f} s.")
            return result, diagnostics
        except Exception as exc:
            if isinstance(exc, InterruptedError):
                raise
            if backend == 'gpu':
                raise ValueError(f'GPU solve unavailable or failed: {exc}. Select Auto or CPU to use the CPU backend.') from exc
            notes.append(str(exc))
            if log:
                log(f'CUDA unavailable; using CPU: {exc}')
        finally:
            # Release cached GPU allocations between regulator/refinement solves.
            if 'cp' in locals():
                gpu_matrix = gpu_rhs = inverse = preconditioner = None
                if 'result' in locals() and isinstance(result, cp.ndarray):
                    result = None
                try:
                    cp.get_default_memory_pool().free_all_blocks()
                except Exception:
                    pass
    iterations[0] = 0
    if len(rhs) < 200000:
        result = linalg.spsolve(matrix, rhs)
        name = 'CPU direct'
    else:
        inverse = 1/diagonal
        preconditioner = linalg.LinearOperator(matrix.shape, matvec=lambda x: inverse*x)
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=1):
            result, info = linalg.cg(matrix, rhs, M=preconditioner, rtol=1e-10, atol=1e-11,
                                    maxiter=maximum, callback=count)
        if info != 0:
            raise ValueError(f'CPU CG did not converge after {iterations[0]} iterations; increase spacing.')
        name = 'CPU CG'
    return result, dict(backend=name, iterations=iterations[0], solve_seconds=time.perf_counter()-started,
                        backend_notes=notes)
