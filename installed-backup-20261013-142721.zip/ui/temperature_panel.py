"""Interactive thermal view with an exact cell readout in PCB coordinates."""
import wx
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg
from plotter import Plotter
from temperature_map import TemperatureMap


class TemperaturePanel(wx.Panel):
    def __init__(self, parent, result):
        super().__init__(parent)
        self.temperatures = TemperatureMap(result)
        peak = self.temperatures
        x, y = peak.maximum_xy
        self.maximum_label = wx.StaticText(self, label=f'Highest simulated temperature: {peak.maximum_c:.2f} °C at X={x:.2f}, Y={y:.2f} mm')
        self.pointer_label = wx.StaticText(self, label='Pointer temperature: move the mouse over the board')
        self.figure, self.axes = Plotter().temperature_figure(result, peak)
        self.canvas = FigureCanvasWxAgg(self, wx.ID_ANY, self.figure)
        toolbar = NavigationToolbar2WxAgg(self.canvas)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.maximum_label, 0, wx.ALL, 5)
        sizer.Add(self.pointer_label, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        sizer.Add(self.canvas, 1, wx.EXPAND)
        sizer.Add(toolbar, 0, wx.EXPAND)
        self.SetSizer(sizer)
        self._connections = [self.canvas.mpl_connect('motion_notify_event', self.on_motion),
                             self.canvas.mpl_connect('figure_leave_event', self.on_leave),
                             self.canvas.mpl_connect('axes_leave_event', self.on_leave)]
        self.Bind(wx.EVT_WINDOW_DESTROY, self.on_destroy)

    def on_motion(self, event):
        if event.inaxes is not self.axes or event.xdata is None or event.ydata is None:
            self.on_leave(event)
            return
        x, y = event.xdata, -event.ydata  # Plot Y is flipped; report PCB Y.
        temperature = self.temperatures.lookup(x, y)
        value = f'{temperature:.2f} °C (thermal cell)' if temperature is not None else 'outside modeled board'
        self.pointer_label.SetLabel(f'X={x:.2f}, Y={y:.2f} mm | Temperature: {value}')

    def on_leave(self, event):
        self.pointer_label.SetLabel('Pointer temperature: — (move over the board)')

    def on_destroy(self, event):
        if event.GetEventObject() is self:
            for connection in self._connections:
                self.canvas.mpl_disconnect(connection)
            self.figure.clear()
        event.Skip()
