"""Validated sparse DC network solver; conductances are in siemens."""
import warnings
import numpy as np
import scipy.sparse as sparse
import scipy.sparse.linalg as linalg
from scipy.sparse.csgraph import connected_components


class Solver:
    def __init__(self, debug=False, log_callback=None):
        self.debug = debug
        self.log_callback = log_callback
        self.diagnostics = {}

    def _log(self, msg):
        if self.log_callback:
            self.log_callback(f"[SOLVER] {msg}")

    def solve(self, mesh, sources, loads):
        self.diagnostics = {}
        nodes = list(mesh.nodes)
        if not nodes:
            raise ValueError("Mesh has no nodes. Reduce mesh spacing or check geometry.")
        if len(set(nodes)) != len(nodes):
            raise ValueError("Duplicate mesh node IDs.")
        index = {nid: i for i, nid in enumerate(nodes)}
        n = len(nodes)
        if len(getattr(mesh, 'G_coo_data', [])):
            try:
                rows = [index[nid] for nid in mesh.G_coo_row]
                cols = [index[nid] for nid in mesh.G_coo_col]
            except KeyError as exc:
                raise ValueError("Matrix references an unknown mesh node.") from exc
            g = sparse.coo_matrix((mesh.G_coo_data, (rows, cols)), shape=(n, n)).tocsr()
        else:
            rows, cols, values = [], [], []
            for u, v, conductance in mesh.edges:
                if u not in index or v not in index or not np.isfinite(conductance) or conductance <= 0:
                    raise ValueError("Invalid mesh edge.")
                a, b = index[u], index[v]
                rows.extend([a, b, a, b]); cols.extend([a, b, b, a])
                values.extend([conductance, conductance, -conductance, -conductance])
            g = sparse.coo_matrix((values, (rows, cols)), shape=(n, n)).tocsr()
        g.eliminate_zeros()
        if not np.all(np.isfinite(g.data)):
            raise ValueError("Non-finite mesh conductance.")
        asymmetry = g - g.T
        if asymmetry.nnz and np.max(np.abs(asymmetry.data)) > 1e-9:
            raise ValueError("Conductance matrix is not symmetric.")
        fixed = {}
        for source in sources:
            nid, value = source['node_id'], float(source['voltage'])
            if nid not in index or not np.isfinite(value):
                raise ValueError("Invalid or unmapped voltage source.")
            i = index[nid]
            if i in fixed and fixed[i] != value:
                raise ValueError("Conflicting sources on the same node.")
            fixed[i] = value
        if not fixed:
            raise ValueError("No mapped voltage source.")
        rhs = np.zeros(n)
        for load in loads:
            nid, current = load['node_id'], float(load['current'])
            if nid not in index or not np.isfinite(current) or current < 0:
                raise ValueError("Invalid or unmapped current load.")
            rhs[index[nid]] -= current
        count, labels = connected_components(g, directed=False)
        powered = set(labels[list(fixed)])
        active = np.array([label in powered for label in labels])
        if np.any((~active) & (rhs != 0)):
            raise ValueError("Load disconnected from every source. Check layout and mesh spacing.")
        excluded = int(np.count_nonzero(~active))
        if excluded:
            self._log(f"Excluded {excluded} unpowered copper nodes (no assigned voltage).")
        fixed_indices = np.array(sorted(fixed), dtype=int)
        free = np.array([i for i in range(n) if active[i] and i not in fixed], dtype=int)
        voltage = np.zeros(n)
        voltage[fixed_indices] = [fixed[i] for i in fixed_indices]
        if len(free):
            reduced = g[free][:, free]
            b = rhs[free] - g[free][:, fixed_indices] @ voltage[fixed_indices]
            with warnings.catch_warnings():
                warnings.simplefilter('error', linalg.MatrixRankWarning)
                try:
                    voltage[free] = linalg.spsolve(reduced, b)
                except (linalg.MatrixRankWarning, RuntimeError) as exc:
                    raise ValueError("Singular or invalid electrical mesh.") from exc
        if not np.all(np.isfinite(voltage[active])):
            raise ValueError("Non-finite voltage solution.")
        residual = g @ voltage - rhs
        max_residual = float(np.max(np.abs(residual[free]))) if len(free) else 0.0
        load_current = float(-rhs.sum())
        supplied = float(residual[fixed_indices].sum())
        balance = abs(supplied - load_current)
        tolerance = 1e-8 + 1e-7 * max(1.0, load_current, abs(supplied))
        if max_residual > tolerance or balance > tolerance:
            raise ValueError(f"Electrical validation failed: residual {max_residual:.3g} A, imbalance {balance:.3g} A.")
        # Subtract a voltage reference on each powered island to avoid cancellation.
        shifted = voltage.copy()
        for label in powered:
            members = labels == label
            shifted[members] -= voltage[next(i for i in fixed if labels[i] == label)]
        power = float(shifted @ (g @ shifted))
        self.diagnostics = dict(load_current_a=load_current, source_current_a=supplied,
                                source_currents_a={nodes[i]: float(residual[i]) for i in fixed_indices},
                                residual_a=max_residual, balance_a=balance,
                                copper_loss_w=max(0.0, power), excluded_nodes=excluded, islands=count)
        self._log(f"Validated: source {supplied:.6g} A, load {load_current:.6g} A, copper loss {power:.6g} W, residual {max_residual:.3g} A.")
        return {nid: float(voltage[i]) for i, nid in enumerate(nodes) if active[i]}
