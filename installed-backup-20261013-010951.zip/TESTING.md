# Electrical accuracy update

The shared KiPIDA folder contains the updated source. Original core files are in
`review_backup/`. The PCM ZIP beside the folder contains only runtime files and package metadata;
it excludes the test environment, caches, backups, and development scripts.

## Test in KiCad

1. Use KiCad **9.0.1 or newer** and enable its IPC API.
2. In KiCad's Plugin and Content Manager choose **Install from File** and select
   `KiPIDA-PCM.zip` beside this folder. It contains root `metadata.json` and a
   `plugins/` payload, validated against the official KiCad schemas.
   `KiPIDA-fixed.zip` is now an identical compatibility copy of this PCM installer.
3. Restart KiCad. If you previously installed KiPIDA manually, remove that old
   manual copy to avoid two plugins with the same identifier. Keep your project
   configuration files. This build uses the original KiPIDA identifier.
4. Open a board with a physical stackup, refill zones, and launch KiPIDA. The
   plugin runtime requires NumPy, SciPy, Shapely, Matplotlib, wxPython, and
   kicad-python, listed in `requirements.txt`. The shared `.venv/` is only for tests.
5. Keep **Check mesh convergence** enabled. Start with 0.1 mm spacing. If a pad
   or annular ring has no mesh nodes, or refinement changes voltage drop/total
   loss by more than 5%, halve the spacing and run again.
6. Verify voltage drop, total copper loss (W), current balance, and mesh status.
   Unmapped or disconnected loads now stop the simulation with an explanation.
7. Try a regulator chain: a 5 V / 1 A load supplied by a 10 V input at 80%
   efficiency draws 0.625 A at its input when the local input voltage is 10 V.
   Copper and series drops increase switching-regulator input current.

The previous ZIP was a manual-extraction archive, which caused the PCM error
about missing metadata.json. Neither the plugin icon nor the packaged PNGs
contain iCCP or cHRM chunks; those warnings have not been traced to KiPIDA.

## Applied changes

- Removed duplicate regulator input-current stamping.
- Removed 0.05 mm copper widening on each side of traces and vias.
- Use KiCad's pad polygons and actual copper layers for terminals and extraction.
- Preserve polygon holes and prevent neighbor links across copper gaps.
- Weight lateral conductance by the copper width at each cell face.
- Use finished drill diameter, plating thickness, and physical stackup distances
  for via/PTH barrels. Slotted PTH barrels use the slot perimeter.
- Do not attach vertical connections to nodes outside the contact geometry.
- Map IPC layer IDs correctly in the offline fallback; connected-board stackup
  failures stop the run instead of substituting a guessed two-layer stackup.
- Eliminate voltage boundaries while preserving matrix symmetry; reject invalid
  boundaries, non-finite solutions, excessive residuals, and current imbalance.
- Exclude unloaded, unpowered copper islands from voltage results and plots.
- Clear results on failure so earlier or partial results are not shown as valid.
- Compare coarse and half-spacing meshes, using the refined results after a pass.
- Report total copper loss and correct the README's unimplemented feature claims.

## Verification

Run from this folder in PowerShell:

```powershell
$env:MPLCONFIGDIR = Join-Path (Get-Location) '.mpl-cache'
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

39 checks passed, with one GUI import check skipped because wxPython is unavailable
in the isolated test environment. Checks cover analytical rectangular-trace
resistance at three mesh spacings, copper loss, holes, gaps, via conductance and
vertical connectivity, real IPC pad polygon types, disconnected loads, sparse node
IDs, terminal layer restrictions, and production rail orchestration. The production
orchestration check also exercises successful and rejected mesh refinement.

The live KiCad connection and dialog still need your test.

## Model limits

This update implements electrical corrections and total Joule power loss. It does
not add local current-density plots or temperature prediction. Copper resistivity
is fixed. Explicitly stitched nets are solved together; return-path resistance is omitted.

Via/PTH plating defaults to **25 micrometres**, logged during meshing. The model
accepts a `via_plating_mm` stackup field, but a user-editable plating control is
not yet present. Barrel contacts remain lumped at a representative node within
each annular pad; current crowding near these contacts needs further refinement.

The 5% refinement check covers rail voltage drop, integrated copper loss, and
series-component current/drop/loss, not local
peak current density. Curved API polygon boundaries are approximated by segments
of at most two degrees. The rectangular grid can require small spacing for narrow
or diagonal features and is capped at two million grid points across layers.

## Series components (0.6.0)

1. Select the supply rail and set its source and supply voltage at the actual
   input connector. Put the load at its real downstream terminal.
2. Click **+ Series Component**, choose F1, and select its two pads. The pad nets
   come from the board; missing nets are added to the rail list automatically.
3. Enter the component resistance in **milliohms**, using a datasheet or measured
   value. For example, 20 mOhm at 2 A produces 40 mV drop and 0.08 W loss.
   Zero means an ideal connection. Clear **Connected** to model an open fuse.
4. Remove any artificial source or load previously placed at F1 to analyze
   the two sides separately. The fuse is now the connection between those sides.
   The intermediate rail's nominal voltage does not clamp its solved voltage.
5. Run with mesh convergence enabled. Read signed A-to-B component current,
   A-minus-B voltage, component loss, and separate total copper/component losses.
6. Double-click a series row on either rail to edit it; **- Remove** deletes
   the link. Save Config persists it. Existing version 1.0 files still load;
   newly saved files use version 1.1 and require this updated plugin.

Passive links are bidirectional and can form branched networks. Contacts are
lumped equipotential electrodes within each selected pad. Ideal-link loop currents
may be indeterminate and are labelled accordingly. Regulator dependencies must be
acyclic, with distinct input/output networks and uniquely attributable output
terminals. Switching inputs use an iterated constant-power load; failures to
converge stop the solve. Linear-regulator quiescent current is omitted.

This is a fixed-resistance electrical model: component watts estimate Joule heat
production, not temperature, fuse trip time, or a coupled thermal solution.

## Startup troubleshooting

The installed launcher appends startup details to `%TEMP%/kipida_entry.log`
and explicitly raises the analysis dialog on Windows. Connection failures
produce a foreground error with the exception and log path.

If clicking the toolbar icon produces no new log entry, KiCad has not invoked
the launcher. Restart the PCB Editor and KiCad manager to reload the plugin,
and check that the tooltip identifies **Ki-PIDA Simulation**. Keep the board
open when launching. The shared folder also contains `Start KiPIDA.cmd`, a
direct launcher for this user's KiCad 9 installed runtime; it bypasses toolbar
dispatch and connects to the running board without editing it.

## Windows toolbar bridge (0.6.1)

KiCad 9's IPC toolbar dispatch did not start the launcher on the tested system,
although directly starting the same installed runtime opened the dialog. This
build registers a minimal pcbnew ActionPlugin toolbar bridge on Windows. It
launches the isolated runtime without importing analysis dependencies inside
KiCad. The electrical analysis and board access still use IPC. The manifest's
IPC action remains available as **Ki-PIDA Simulation (IPC)** with its toolbar
button hidden, avoiding duplicate icons after reload.

Reload Python action plugins or reopen the PCB Editor after this update. The
new toolbar tooltip is **Open KiPIDA (KiCad 9 toolbar bridge)**. Bridge launch
events are appended to `%TEMP%/kipida_toolbar.log`; analysis startup is logged
in `%TEMP%/kipida_entry.log`. Missing runtime files produce a KiCad error dialog.
42 executable checks pass, plus one GUI import check is skipped in the isolated
test environment. The real KiCad-managed Python runtime also exercises the
bridge launch with the open board. Actual toolbar dispatch needs user testing.

## Series dialog fix (0.6.2)

KiCad IPC footprint references contain BoardText objects; the series dialog
now extracts their string values before sorting component choices. Constructor
failures are logged and displayed rather than appearing as an inactive button.
Regression coverage includes actual FootprintInstance, Field, BoardText and Pad
protobuf wrappers. 44 executable checks pass with one GUI import check skipped.
The dialog was also constructed and displayed against the user's open board.

## Series chain list and defaults (0.6.3)

The component list shows every series link in the selected net's connected
chain, including open links and links farther downstream. Each row identifies
both nets and pads; editing and deletion use the link's owning rail. A newly
added link is selected and scrolled into view. If it belongs to a separate
chain, its first rail is selected automatically so the new link is visible.
New series components default to 0 mOhm (ideal connection); editing preserves
the configured resistance. Series, source/load and regulator component choices
use natural reference sorting (R2, R3, R10, R29); series pad numbers also sort
numerically. 48 executable checks pass with one GUI import check skipped.
Real wx controls verified downstream rows, deletion, default and ordering.

## Filled-zone boundary reconstruction (0.6.4)

Some IPC filled polygons express holes or islands with doubled zero-width
boundary seams. Shapely considers these rings self-intersecting. The parser
now reconstructs valid area polygons and discards leftover line geometry.
It accepts the reconstruction only when the copper area is preserved within
a tolerance of max(1e-12 mm2, 1e-10 times the original area). Repairs that
change copper area still fail, with the net/layer and validity reason included.
This does not enlarge copper or treat a boundary seam as a conductive bridge.

All 66 filled-zone polygons on the open board passed the corrected parser.
52 executable tests passed, with one GUI import skipped. New regressions cover
bridged holes, disconnected islands, genuine crossing rejection, and explicit
holes. The complete simulation of the user's unsaved configuration still needs
a rerun. Save Config before closing and reopening KiPIDA to load this update.
