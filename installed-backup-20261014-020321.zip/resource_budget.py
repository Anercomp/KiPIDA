"""Conservative RAM estimates before allocating a mesh or assembled network."""
import math
import os

GIB = 1024**3


def available_ram():
    if os.name == 'nt':
        import ctypes
        class Status(ctypes.Structure):
            _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong)] + [(name, ctypes.c_ulonglong) for name in
                ('total', 'available', 'page_total', 'page_available', 'virtual_total', 'virtual_available', 'extended')]
        status = Status(); status.length = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return status.available
    try:
        return os.sysconf('SC_AVPHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')
    except (AttributeError, ValueError):
        return 4*GIB


def default_budget_gb():
    return max(.25, min(8, available_ram()/GIB*.25))


def grid_estimate(geometry, spacing):
    shapes = [shape for shape in geometry.values() if not shape.is_empty]
    if not shapes:
        return 0, 0
    xmin = min(s.bounds[0] for s in shapes); xmax = max(s.bounds[2] for s in shapes)
    ymin = min(s.bounds[1] for s in shapes); ymax = max(s.bounds[3] for s in shapes)
    plane = (math.ceil((xmax-xmin)/spacing+2)+1)*(math.ceil((ymax-ymin)/spacing+2)+1)
    nodes = min(plane*len(shapes), sum(math.ceil(s.area/spacing**2+s.length/spacing+16) for s in shapes))
    # Includes coordinate/matrix arrays, assembly, CPU validation and CG workspace.
    return plane*len(shapes), plane*40+nodes*800


def check_budget(estimated_bytes, budget_gb, retained_bytes=0):
    if not math.isfinite(budget_gb) or budget_gb <= 0:
        raise ValueError('Memory budget must be finite and positive.')
    allowed = min(budget_gb*GIB, available_ram()*.7)
    total = estimated_bytes+retained_bytes
    if total > allowed:
        raise ValueError(f'Mesh/solver estimated RAM {total/GIB:.2f} GB exceeds available budget {allowed/GIB:.2f} GB. Increase spacing or memory budget. Refinement needs four times as many grid points.')
    return total
