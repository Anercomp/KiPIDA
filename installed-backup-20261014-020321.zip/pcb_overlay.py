"""PCB polygon paths with preserved holes in the plotted (X, -Y) coordinates."""
import numpy as np
from matplotlib.path import Path
from shapely.geometry.polygon import orient


def polygon_paths(geometry):
    if geometry is None or geometry.is_empty or geometry.area <= 0:
        return []
    polygons = polygon_paths_geometry(geometry)
    paths = []
    for polygon in polygons:
        polygon = orient(polygon, sign=1)
        vertices, codes = [], []
        for ring in [polygon.exterior, *polygon.interiors]:
            coordinates = np.asarray(ring.coords).copy()
            coordinates[:, 1] *= -1
            vertices.extend(coordinates)
            codes.extend([Path.MOVETO]+[Path.LINETO]*(len(coordinates)-2)+[Path.CLOSEPOLY])
        paths.append(Path(vertices, codes))
    return paths


def polygon_paths_geometry(geometry):
    if geometry.geom_type == 'Polygon':
        return [geometry]
    if hasattr(geometry, 'geoms'):
        return [p for part in geometry.geoms for p in polygon_paths_geometry(part)]
    return []
