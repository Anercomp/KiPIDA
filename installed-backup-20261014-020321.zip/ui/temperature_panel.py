"""Interactive thermal view with an exact cell readout in PCB coordinates."""
import wx
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg
from plotter import Plotter
from temperature_map import TemperatureMap


class ThermalToolbar(NavigationToolbar2WxAgg):
    # Constrained layout already arranges this single plot and its colorbar.
    # The generic subplot editor opens an unmanaged window from a modal dialog.
    toolitems = tuple(item for item in NavigationToolbar2WxAgg.toolitems
                      if item[3] != 'configure_subplots')


class TemperaturePanel(wx.Panel):
    def __init__(self, parent, result, overlay_loader=None):
        super().__init__(parent)
        self.temperatures = TemperatureMap(result)
        peak = self.temperatures
        x, y = peak.maximum_xy
        self.maximum_label = wx.StaticText(self, label=f'Highest simulated temperature: {peak.maximum_c:.2f} °C at X={x:.2f}, Y={y:.2f} mm')
        self.pointer_label = wx.StaticText(self, label='Pointer temperature: move the mouse over the board')
        self.figure, self.axes = Plotter().temperature_figure(result, peak)
        self.overlay_loader = overlay_loader
        self.overlay_geometry = result.get('overlay_copper')
        self.overlay_artists = {}
        self.overlay_outline = []
        self.layer_ids = list(result.get('overlay_layer_names', {}))
        self.overlay_toggle = wx.CheckBox(self, label='PCB copper overlay')
        self.overlay_layer = wx.Choice(self, choices=[result['overlay_layer_names'][lid] for lid in self.layer_ids])
        if self.layer_ids:
            self.overlay_layer.SetSelection(0)
        self.overlay_opacity = wx.Slider(self, value=35, minValue=0, maxValue=100, size=(150, -1))
        self.opacity_label = wx.StaticText(self, label='Opacity: 35%')
        controls = wx.BoxSizer(wx.HORIZONTAL)
        controls.Add(self.overlay_toggle, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 10)
        controls.Add(self.overlay_layer, 0, wx.RIGHT, 10)
        controls.Add(self.opacity_label, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        controls.Add(self.overlay_opacity, 0)
        self.overlay_toggle.Enable(bool(self.layer_ids) and (overlay_loader is not None or self.overlay_geometry is not None))
        self.overlay_layer.Disable()
        self.overlay_opacity.Disable()
        self.overlay_toggle.Bind(wx.EVT_CHECKBOX, self.on_overlay)
        self.overlay_layer.Bind(wx.EVT_CHOICE, self.on_overlay)
        self.overlay_opacity.Bind(wx.EVT_SLIDER, self.on_overlay)
        self.canvas = FigureCanvasWxAgg(self, wx.ID_ANY, self.figure)
        self.toolbar = ThermalToolbar(self.canvas)
        self.toolbar.SetToolTip('Plot navigation: reset, back/forward, pan, zoom and save image')
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.maximum_label, 0, wx.ALL, 5)
        sizer.Add(self.pointer_label, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        sizer.Add(controls, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)
        sizer.Add(self.canvas, 1, wx.EXPAND)
        sizer.Add(self.toolbar, 0, wx.EXPAND)
        self.SetSizer(sizer)
        self._connections = [self.canvas.mpl_connect('motion_notify_event', self.on_motion),
                             self.canvas.mpl_connect('figure_leave_event', self.on_leave),
                             self.canvas.mpl_connect('axes_leave_event', self.on_leave)]
        self.Bind(wx.EVT_WINDOW_DESTROY, self.on_destroy)

    def on_overlay(self, event):
        from matplotlib.patches import PathPatch
        from pcb_overlay import polygon_paths
        enabled = self.overlay_toggle.GetValue()
        if enabled and self.overlay_geometry is None:
            try:
                with wx.BusyCursor():
                    self.overlay_geometry = self.overlay_loader()
            except Exception as exc:
                self.overlay_toggle.SetValue(False)
                enabled = False
                wx.MessageBox(str(exc), 'Could not read PCB overlay', wx.OK | wx.ICON_ERROR)
        opacity = self.overlay_opacity.GetValue()/100
        self.opacity_label.SetLabel(f'Opacity: {self.overlay_opacity.GetValue()}%')
        self.overlay_layer.Enable(enabled)
        self.overlay_opacity.Enable(enabled)
        layer = self.layer_ids[self.overlay_layer.GetSelection()] if self.layer_ids else None
        if enabled and layer not in self.overlay_artists:
            # Adding copper must not change zoom limits or autoscale the thermal view.
            xlim, ylim = self.axes.get_xlim(), self.axes.get_ylim()
            patches = []
            for path in polygon_paths(self.overlay_geometry.get(layer)):
                patch = PathPatch(path, facecolor='cyan', edgecolor='white', linewidth=.25, zorder=3)
                self.axes.add_patch(patch)
                patches.append(patch)
            self.overlay_artists[layer] = patches
            if not self.overlay_outline:
                for path in polygon_paths(self.temperatures.region):
                    outline = PathPatch(path, facecolor='none', edgecolor='white', linewidth=1, zorder=4)
                    self.axes.add_patch(outline)
                    self.overlay_outline.append(outline)
            self.axes.set_xlim(xlim); self.axes.set_ylim(ylim)
        for lid, patches in self.overlay_artists.items():
            for patch in patches:
                patch.set_visible(enabled and lid == layer)
                patch.set_alpha(opacity)
        for outline in self.overlay_outline:
            outline.set_visible(enabled)
            outline.set_alpha(opacity)
        self.canvas.draw_idle()

    def on_motion(self, event):
        if event.inaxes is not self.axes or event.xdata is None or event.ydata is None:
            self.on_leave(event)
            return
        x, y = event.xdata, -event.ydata  # Plot Y is flipped; report PCB Y.
        temperature = self.temperatures.lookup(x, y)
        value = f'{temperature:.2f} °C (thermal cell)' if temperature is not None else 'outside modeled board'
        self.pointer_label.SetLabel(f'X={x:.2f}, Y={y:.2f} mm | Temperature: {value}')

    def on_leave(self, event):
        self.pointer_label.SetLabel('Pointer temperature: — (move over the board)')

    def on_destroy(self, event):
        if event.GetEventObject() is self:
            for connection in self._connections:
                self.canvas.mpl_disconnect(connection)
            self.figure.clear()
        event.Skip()
