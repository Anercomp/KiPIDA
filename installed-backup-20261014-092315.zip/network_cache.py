"""Bounded session cache for prepared DC networks, never for their solutions."""
from collections import OrderedDict
import hashlib
import sys
import types

import numpy as np


def _mesh_signature(mesh):
    """Check mutable meshes too; object identity alone cannot detect edited edges."""
    digest = hashlib.blake2b(digest_size=20)
    if isinstance(mesh.nodes, range):
        digest.update(repr(mesh.nodes).encode())
    else:
        digest.update(np.asarray(mesh.nodes, dtype=np.int64).tobytes())
    for name in ('G_coo_row', 'G_coo_col', 'G_coo_data'):
        value = getattr(mesh, name, ())
        digest.update(memoryview(value) if len(value) else b'')
    if not len(getattr(mesh, 'G_coo_data', ())):
        digest.update(repr(mesh.edges).encode())
    return id(mesh), digest.digest()


def network_signature(meshes, links, sources, loads, resolve, backend):
    """Currents change the RHS; terminals, boundaries and conductances change A."""
    def terminal(net, ref, pads):
        return net, ref, tuple(pads), tuple(int(node) for node in resolve(meshes[net], ref, pads))
    return (backend, tuple((net, _mesh_signature(mesh)) for net, mesh in meshes.items()),
            tuple((link.ref_des, link.net_a, link.pad_a, link.net_b, link.pad_b,
                   link.resistance_ohm, link.closed, link.kind,
                   terminal(link.net_a, link.ref_des, [link.pad_a]),
                   terminal(link.net_b, link.ref_des, [link.pad_b])) for link in links),
            tuple((terminal(net, ref, pads), voltage) for net, ref, pads, voltage in sources),
            tuple(terminal(net, ref, pads) for net, ref, pads, _ in loads))


def prepared_bytes(prepared):
    """Conservative retained RAM/VRAM estimate, including native sparse factors."""
    seen = set()
    def size(value):
        if value is None or isinstance(value, (str, bytes, int, float, bool, types.ModuleType, type)) or callable(value):
            return 0
        key = id(value)
        if key in seen:
            return 0
        seen.add(key)
        if hasattr(value, 'nbytes'):
            return int(value.nbytes)
        if hasattr(value, 'data') and hasattr(value, 'indices') and hasattr(value, 'indptr'):
            return size(value.data)+size(value.indices)+size(value.indptr)
        if isinstance(value, dict):
            return sys.getsizeof(value)+sum(size(item) for item in value.values())
        if isinstance(value, (list, tuple)):
            return sys.getsizeof(value)+sum(size(item) for item in value)
        # array.array sparse stamps and Python fallback node storage.
        if hasattr(value, 'buffer_info'):
            return sys.getsizeof(value)
        if hasattr(value, 'L') and hasattr(value, 'U'):
            return int(1.5*(size(value.L)+size(value.U)))
        if hasattr(value, '__dict__') and not callable(value):
            return sys.getsizeof(value)+size(vars(value))
        return sys.getsizeof(value)
    return size(prepared)


class PreparedNetworkCache:
    """LRU cache owned by a simulation window and released when it closes."""
    def __init__(self, max_bytes=1024**3, max_entries=8):
        self.max_bytes = max(0, int(max_bytes))
        self.max_entries = max(0, int(max_entries))
        self.entries = OrderedDict()
        self.hits = self.misses = 0

    @property
    def bytes_used(self):
        return sum(size for _, size in self.entries.values())

    def get(self, key):
        record = self.entries.pop(key, None)
        if record is None:
            self.misses += 1
            return None
        self.entries[key] = record
        self.hits += 1
        return record[0]

    def store(self, key, prepared):
        old = self.entries.pop(key, None)
        if old is not None and old[0] is not prepared:
            old[0].close()
        amount = prepared_bytes(prepared)
        if self.max_entries == 0 or amount > self.max_bytes:
            prepared.close()
            return False
        self.entries[key] = prepared, amount
        self.trim()
        return key in self.entries

    def trim(self):
        while self.entries and (len(self.entries) > self.max_entries or self.bytes_used > self.max_bytes):
            _, (prepared, _) = self.entries.popitem(last=False)
            prepared.close()

    def set_budget(self, max_bytes):
        self.max_bytes = max(0, int(max_bytes))
        self.trim()

    def clear(self):
        while self.entries:
            _, (prepared, _) = self.entries.popitem()
            prepared.close()

    close = clear
